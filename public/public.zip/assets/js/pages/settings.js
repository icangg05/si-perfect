$(document).ready(function() {
    
    "use strict";
    
    $('select').select2();

});